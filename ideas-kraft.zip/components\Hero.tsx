export function Hero() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="absolute inset-0 bg-grid opacity-40" />
      <div className="absolute top-0 left-1/2 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-primary/20 blur-[120px]" />
      <div className="absolute top-20 right-0 h-[300px] w-[300px] rounded-full bg-primary-2/15 blur-[100px]" />

      <div className="relative mx-auto grid max-w-7xl gap-14 px-6 lg:grid-cols-2 lg:items-center">
        <div>
          <p className="mb-5 inline-flex rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-primary-2">
            Digital Marketing Agency
          </p>
          <h1 className="max-w-3xl text-5xl font-bold leading-[1.05] tracking-tight text-white md:text-6xl lg:text-7xl">
            We craft ideas into{" "}
            <span className="bg-gradient-to-r from-primary via-accent to-primary-2 bg-clip-text text-transparent">
              digital growth
            </span>
            .
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-8 text-muted">
            Ideas KRaft helps ambitious brands stand out, attract the right
            audience, and convert attention into measurable results through
            strategy, creativity, and performance marketing.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <a
              href="#contact"
              className="rounded-full bg-gradient-to-r from-primary to-primary-2 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-primary/25 transition hover:opacity-90"
            >
              Start Your Project
            </a>
            <a
              href="#work"
              className="rounded-full border border-white/15 px-7 py-3.5 text-sm font-semibold text-white transition hover:border-primary/50 hover:bg-white/5"
            >
              View Our Work
            </a>
          </div>

          <div className="mt-12 grid grid-cols-3 gap-6 border-t border-white/10 pt-8">
            {[
              { value: "120+", label: "Projects delivered" },
              { value: "98%", label: "Client satisfaction" },
              { value: "3.5x", label: "Average ROI growth" },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="text-2xl font-bold text-white md:text-3xl">
                  {stat.value}
                </div>
                <div className="mt-1 text-sm text-muted">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative">
          <div className="glass rounded-3xl p-6 shadow-2xl shadow-black/20 md:p-8">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <p className="text-sm text-muted">Campaign Performance</p>
                <p className="text-2xl font-bold text-white">Growth Snapshot</p>
              </div>
              <span className="rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-300">
                +42% this month
              </span>
            </div>
            <div className="space-y-4">
              {[
                { label: "Brand Awareness", value: 88, color: "from-primary to-primary-2" },
                { label: "Lead Generation", value: 76, color: "from-accent to-primary" },
                { label: "Conversion Rate", value: 64, color: "from-primary-2 to-emerald-400" },
              ].map((item) => (
                <div key={item.label}>
                  <div className="mb-2 flex justify-between text-sm">
                    <span className="text-muted">{item.label}</span>
                    <span className="text-white">{item.value}%</span>
                  </div>
                  <div className="h-2.5 rounded-full bg-white/5">
                    <div
                      className={`h-2.5 rounded-full bg-gradient-to-r ${item.color}`}
                      style={{ width: `${item.value}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-sm text-muted">Qualified Leads</p>
                <p className="mt-1 text-2xl font-bold text-white">2,480</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="text-sm text-muted">Ad Spend ROI</p>
                <p className="mt-1 text-2xl font-bold text-white">4.2x</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
