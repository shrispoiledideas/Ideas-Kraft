const projects = [
  {
    category: "Brand + Social",
    title: "Bloom & Co. Rebrand",
    result: "180% increase in social engagement",
    description:
      "A complete brand refresh and social strategy that gave a lifestyle brand a bold new voice.",
  },
  {
    category: "Performance Marketing",
    title: "NovaTech Lead Engine",
    result: "3.2x return on ad spend",
    description:
      "Targeted paid campaigns and landing page optimization that turned clicks into qualified leads.",
  },
  {
    category: "SEO + Content",
    title: "Urban Eats Growth",
    result: "220% organic traffic growth",
    description:
      "A content-led SEO strategy that put a local food brand on the map — literally and digitally.",
  },
];

export function Work() {
  return (
    <section id="work" className="py-20 md:py-28 bg-white/[0.02]">
      <div className="mx-auto max-w-7xl px-6">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary-2">
              Selected Work
            </p>
            <h2 className="mt-4 text-3xl font-bold tracking-tight text-white md:text-5xl">
              Results that speak for themselves
            </h2>
          </div>
          <a
            href="#contact"
            className="text-sm font-semibold text-primary-2 transition hover:text-white"
          >
            Work with us &rarr;
          </a>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {projects.map((project, i) => (
            <article
              key={project.title}
              className="group overflow-hidden rounded-3xl border border-card-border bg-card/60 transition hover:border-primary/40"
            >
              <div className="relative h-52 overflow-hidden bg-gradient-to-br from-primary/25 via-[#1a2340] to-primary-2/20">
                <div className="absolute inset-0 bg-grid opacity-30" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-7xl font-bold text-white/5">
                    0{i + 1}
                  </span>
                </div>
                <div className="absolute bottom-4 left-4 rounded-full bg-black/30 px-3 py-1 text-xs font-medium text-white backdrop-blur">
                  {project.category}
                </div>
              </div>
              <div className="p-7">
                <h3 className="text-xl font-semibold text-white">
                  {project.title}
                </h3>
                <p className="mt-3 leading-7 text-muted">{project.description}</p>
                <p className="mt-5 text-sm font-semibold text-primary-2">
                  {project.result}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
