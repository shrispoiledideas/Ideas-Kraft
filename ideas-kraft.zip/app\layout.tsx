import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Ideas KRaft | Digital Marketing Agency",
  description:
    "Ideas KRaft is a digital marketing agency helping brands grow with strategy, creativity, performance marketing, and standout digital experiences.",
  openGraph: {
    title: "Ideas KRaft | Digital Marketing Agency",
    description:
      "Strategy, creativity, and performance marketing that turns bold ideas into measurable growth.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        {children}
      </body>
    </html>
  );
}
