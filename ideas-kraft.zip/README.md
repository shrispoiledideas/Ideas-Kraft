# Ideas KRaft

A modern digital marketing agency website built with [Next.js](https://nextjs.org/) (App Router), [React](https://react.dev/), and [Tailwind CSS](https://tailwindcss.com/). Ready to deploy on [Vercel](https://vercel.com/).

## Features

- Responsive landing page for a digital marketing agency
- Sections: Hero, Services, Work, Process, About, Testimonials, Contact
- Dark, modern UI with Tailwind CSS v4
- TypeScript-ready Next.js App Router structure

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) 18.18+ (LTS recommended)
- npm (included with Node.js)

### Install and run

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Available Scripts

- `npm run dev` - Start the development server
- `npm run build` - Create a production build
- `npm run start` - Start the production server
- `npm run lint` - Run linting

## Deploy to Vercel

1. Push this project to a GitHub repository.
2. Import the repository in [Vercel](https://vercel.com/new).
3. Vercel will detect Next.js automatically; click **Deploy**.

## Project Structure

```text
app/
  globals.css      # Global styles and theme tokens
  layout.tsx       # Root layout and metadata
  page.tsx         # Home page composition
components/
  Navbar.tsx
  Hero.tsx
  Services.tsx
  Work.tsx
  Process.tsx
  About.tsx
  Testimonials.tsx
  Contact.tsx
  Footer.tsx
```

## Customization

- Update brand/content in the files under `components/`.
- Adjust theme colors in `app/globals.css`.
- Update metadata in `app/layout.tsx`.
- Connect the contact form in `components/Contact.tsx` to your form/email service.
