const testimonials = [
  {
    quote:
      "Ideas KRaft didn't just run our campaigns — they understood our brand and transformed how we show up online. The results exceeded every expectation.",
    name: "Sarah Mitchell",
    role: "Founder, Bloom & Co.",
  },
  {
    quote:
      "Sharp strategy, beautiful creative, and real ROI. Their team feels like an extension of ours, and the growth we've seen has been incredible.",
    name: "David Chen",
    role: "Marketing Director, NovaTech",
  },
  {
    quote:
      "From day one, they brought clarity and energy to our marketing. Our traffic, leads, and brand confidence have all leveled up.",
    name: "Priya Sharma",
    role: "Owner, Urban Eats",
  },
];

export function Testimonials() {
  return (
    <section className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary-2">
            Testimonials
          </p>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-white md:text-5xl">
            Trusted by brands that aim higher
          </h2>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {testimonials.map((t) => (
            <blockquote
              key={t.name}
              className="rounded-3xl border border-card-border bg-card/60 p-7"
            >
              <p className="leading-7 text-muted">&ldquo;{t.quote}&rdquo;</p>
              <footer className="mt-6 border-t border-white/10 pt-5">
                <div className="font-semibold text-white">{t.name}</div>
                <div className="text-sm text-muted">{t.role}</div>
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
