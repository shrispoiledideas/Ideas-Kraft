const values = [
  { title: "Strategy First", text: "Every creative decision is backed by insight and intent." },
  { title: "Bold Creativity", text: "We make brands memorable with work that stands out." },
  { title: "Real Results", text: "We measure success by growth, not just impressions." },
];

export function About() {
  return (
    <section id="about" className="py-20 md:py-28 bg-white/[0.02]">
      <div className="mx-auto grid max-w-7xl gap-14 px-6 lg:grid-cols-2 lg:items-center">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary-2">
            About Ideas KRaft
          </p>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-white md:text-5xl">
            Where bold ideas meet digital craft
          </h2>
          <p className="mt-6 text-lg leading-8 text-muted">
            Ideas KRaft is a digital marketing agency built for brands that want
            more than noise. We blend strategic thinking, creative storytelling,
            and performance-driven execution to help businesses grow with
            confidence.
          </p>
          <p className="mt-4 text-lg leading-8 text-muted">
            Whether you&apos;re launching, scaling, or reinventing your brand, we
            become your partner in building meaningful digital presence and
            measurable results.
          </p>
        </div>

        <div className="grid gap-4">
          {values.map((value) => (
            <div
              key={value.title}
              className="rounded-3xl border border-card-border bg-card/60 p-6"
            >
              <h3 className="text-lg font-semibold text-white">{value.title}</h3>
              <p className="mt-2 text-muted">{value.text}</p>
            </div>
          ))}
          <div className="rounded-3xl bg-gradient-to-r from-primary/20 to-primary-2/20 p-6 border border-primary/20">
            <p className="text-sm uppercase tracking-[0.2em] text-primary-2">Our Mission</p>
            <p className="mt-2 text-lg text-white">
              To turn ambitious ideas into powerful digital experiences that drive real business growth.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
