const services = [
  {
    title: "Brand Strategy",
    description:
      "Position your brand with clarity. We define your voice, audience, and message so every campaign has purpose.",
    icon: "◈",
  },
  {
    title: "Social Media Marketing",
    description:
      "Build a scroll-stopping presence with content, community management, and campaigns that spark engagement.",
    icon: "◎",
  },
  {
    title: "SEO & Content",
    description:
      "Get found by the people searching for you. We create content and SEO strategies that drive organic growth.",
    icon: "✦",
  },
  {
    title: "Performance Ads",
    description:
      "Maximize every dollar with data-driven paid campaigns across Google, Meta, and beyond.",
    icon: "▲",
  },
  {
    title: "Web & Creative Design",
    description:
      "From landing pages to full brand identities, we design digital experiences that look great and convert.",
    icon: "▣",
  },
  {
    title: "Analytics & Growth",
    description:
      "Track what matters. We turn data into insights and insights into smarter decisions for sustainable growth.",
    icon: "◉",
  },
];

export function Services() {
  return (
    <section id="services" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary-2">
            Our Services
          </p>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-white md:text-5xl">
            Everything your brand needs to grow
          </h2>
          <p className="mt-5 text-lg text-muted">
            A full-service digital marketing toolkit, crafted to move your
            business forward.
          </p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <article
              key={service.title}
              className="group rounded-3xl border border-card-border bg-card/60 p-7 transition hover:-translate-y-1 hover:border-primary/40 hover:bg-card"
            >
              <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/20 to-primary-2/20 text-xl text-primary-2">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-white">{service.title}</h3>
              <p className="mt-3 leading-7 text-muted">{service.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
