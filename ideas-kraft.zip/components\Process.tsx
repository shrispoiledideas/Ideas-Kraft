const steps = [
  {
    step: "01",
    title: "Discover",
    description:
      "We learn your brand, goals, audience, and challenges to build a foundation for smart strategy.",
  },
  {
    step: "02",
    title: "Strategize",
    description:
      "We craft a tailored marketing roadmap with clear objectives, channels, and measurable KPIs.",
  },
  {
    step: "03",
    title: "Create",
    description:
      "Our team brings ideas to life with compelling content, design, and campaigns built to perform.",
  },
  {
    step: "04",
    title: "Grow",
    description:
      "We launch, measure, and optimize continuously — turning data into momentum and results.",
  },
];

export function Process() {
  return (
    <section id="process" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary-2">
            Our Process
          </p>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-white md:text-5xl">
            A clear path from idea to impact
          </h2>
          <p className="mt-5 text-lg text-muted">
            We keep it simple, strategic, and focused on what moves the needle.
          </p>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((item) => (
            <div
              key={item.step}
              className="relative rounded-3xl border border-card-border bg-card/40 p-7"
            >
              <div className="text-4xl font-bold text-primary/30">{item.step}</div>
              <h3 className="mt-4 text-xl font-semibold text-white">{item.title}</h3>
              <p className="mt-3 leading-7 text-muted">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
