export function Contact() {
  return (
    <section id="contact" className="py-20 md:py-28 bg-white/[0.02]">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 lg:grid-cols-2">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-primary-2">
            Contact Us
          </p>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-white md:text-5xl">
            Let&apos;s build something remarkable
          </h2>
          <p className="mt-6 max-w-lg text-lg leading-8 text-muted">
            Ready to grow your brand? Tell us about your project and we&apos;ll
            craft a strategy tailored to your goals.
          </p>

          <div className="mt-10 space-y-5 text-muted">
            <div className="flex gap-4">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary-2">
                ✉
              </div>
              <div>
                <div className="text-sm text-muted">Email</div>
                <div className="text-white">hello@ideaskraft.com</div>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary-2">
                ☎
              </div>
              <div>
                <div className="text-sm text-muted">Phone</div>
                <div className="text-white">+1 (555) 123-4567</div>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/15 text-primary-2">
                ◌
              </div>
              <div>
                <div className="text-sm text-muted">Location</div>
                <div className="text-white">Serving clients worldwide</div>
              </div>
            </div>
          </div>
        </div>

        <div className="glass rounded-3xl p-7 md:p-8">
          <form className="space-y-5" action="#" method="post">
            <div className="grid gap-5 sm:grid-cols-2">
              <label className="block">
                <span className="mb-2 block text-sm text-muted">Name</span>
                <input
                  type="text"
                  name="name"
                  placeholder="Your name"
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-muted/60 outline-none transition focus:border-primary/60"
                />
              </label>
              <label className="block">
                <span className="mb-2 block text-sm text-muted">Email</span>
                <input
                  type="email"
                  name="email"
                  placeholder="you@company.com"
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-muted/60 outline-none transition focus:border-primary/60"
                />
              </label>
            </div>
            <label className="block">
              <span className="mb-2 block text-sm text-muted">Service interested in</span>
              <select
                name="service"
                className="w-full rounded-xl border border-white/10 bg-[#151d38] px-4 py-3 text-white outline-none transition focus:border-primary/60"
                defaultValue=""
              >
                <option value="" disabled>Select a service</option>
                <option>Brand Strategy</option>
                <option>Social Media Marketing</option>
                <option>SEO & Content</option>
                <option>Performance Ads</option>
                <option>Web & Creative Design</option>
                <option>Full Digital Marketing</option>
              </select>
            </label>
            <label className="block">
              <span className="mb-2 block text-sm text-muted">Message</span>
              <textarea
                name="message"
                rows={5}
                placeholder="Tell us about your project..."
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-muted/60 outline-none transition focus:border-primary/60 resize-none"
              />
            </label>
            <button
              type="submit"
              className="w-full rounded-full bg-gradient-to-r from-primary to-primary-2 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-primary/25 transition hover:opacity-90"
            >
              Send Message
            </button>
            <p className="text-center text-xs text-muted">
              This is a demo form. Connect it to your preferred form handler or email service.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}
