const links = [
  { href: "#services", label: "Services" },
  { href: "#work", label: "Work" },
  { href: "#about", label: "About" },
  { href: "#contact", label: "Contact" },
];

export function Footer() {
  return (
    <footer className="border-t border-white/10 py-12">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 px-6 md:flex-row md:items-center md:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary-2 text-xs font-bold text-white">
              IK
            </span>
            <span className="text-lg font-bold text-white">
              Ideas <span className="text-primary-2">KRaft</span>
            </span>
          </div>
          <p className="mt-3 max-w-sm text-sm text-muted">
            A digital marketing agency crafting bold ideas into measurable growth.
          </p>
        </div>

        <div className="flex flex-wrap gap-6">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm text-muted transition hover:text-white"
            >
              {link.label}
            </a>
          ))}
        </div>
      </div>
      <div className="mx-auto mt-8 max-w-7xl border-t border-white/5 px-6 pt-8 text-sm text-muted">
        &copy; {new Date().getFullYear()} Ideas KRaft. All rights reserved.
      </div>
    </footer>
  );
}
